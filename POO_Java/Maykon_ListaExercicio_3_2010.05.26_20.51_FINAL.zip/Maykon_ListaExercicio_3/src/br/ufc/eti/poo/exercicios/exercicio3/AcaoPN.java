package br.ufc.eti.poo.exercicios.exercicio3;
/**
 * @author Arian Maykon de Araújo Diógenes <arian.maykon@gmail.com>
 */
abstract public class AcaoPN extends Acao {

	abstract public void realizarInvestimento();
}