import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * Questão 3.
 *
 * @author Arian Maykon de Araújo Diógenes <arian.maykon@gmail.com>
 */
public class AcaoView {

	public Scanner scan;

	
	public AcaoView() {
		this.scan = new Scanner(System.in);
	}

	public static void main(String[] args) {
		int qtdAcoes = 0;
		System.out.println("Digite a quantidade de índices do array:");
		AcaoView view = new AcaoView();
		qtdAcoes = view.scan.nextInt();
		if (qtdAcoes > 0) {
			AcaoController controller = new AcaoController(qtdAcoes, view);
			while (true) {
				controller.showAndHandleMenu();
			}
		}

	}
}