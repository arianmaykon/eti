import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 * Questão 2.
 *
 * @author Arian Maykon de Araújo Diógenes <arian.maykon@gmail.com>
 */
public class UsaAcao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List acoes = new ArrayList<Acao>();
		
		Acao acao;
		double valor = 0;
		String descricao;
		Scanner scan = new Scanner(System.in);
		for(int x=1; x<11; x++) {
			System.out.println("Digite o valor de compra da Ação " + x + ":");
			valor = scan.nextDouble();
			acao = new Acao(valor);
			System.out.println("Digite a descrição da Ação " + x + ":");
			descricao = scan.next();
			acao.setDescricao(descricao);
			acoes.add(acao);
		}

		Iterator it = acoes.iterator();
		while(it.hasNext()) {
			acao = (Acao) it.next();
			System.out.println(acao.getDescricao() + "  -  " + acao.getValorVenda());
		}
	}
}