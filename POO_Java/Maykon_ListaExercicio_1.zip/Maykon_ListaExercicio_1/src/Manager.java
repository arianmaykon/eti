import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * Questão 3.
 *
 * @author Arian Maykon de Araújo Diógenes <arian.maykon@gmail.com>
 */
public class Manager {

	private ArrayList<Acao> acoes;

	private Scanner scan;

	public static void main(String[] args) {

		int qtdIndices = 0;
		Manager manager = new Manager();
		manager.scan = new Scanner(System.in);

		System.out.println("Digite a quantidade de índices do array:");
		qtdIndices = manager.scan.nextInt();
		if (qtdIndices > 0) {
			manager.acoes = new ArrayList<Acao>(qtdIndices);
			int opcao = manager.scan.nextInt();
			while (opcao != 100) {
				System.out.println("ESCOLHA UMA OPÇÃO:\n" +
						"\t1 - Cadastrar uma ação\n" +
						"\t2 - Remover uma ação\n" +
						"\t3 - Disponibilizar uma ação para venda\n" +
				"\t100 - PARA SAIR\n");
				switch (opcao) {
					case 1:
						manager.cadastrarAcao(manager);
						break;
					case 2:
						manager.removerAcao(manager);
						break;
					default:
						break;
				}
			}
		}
	}

	private void removerAcao(Manager manager) {
		manager.acoes.remove(0);
		System.out.println("[INFO] Ação removida com sucesso [" + manager.acoes.size() + "]!");
	}

	private void cadastrarAcao(Manager manager) {
		System.out.println("Digite o valor de compra da Ação :");
		double valor = manager.scan.nextDouble();
		
		System.out.println("Digite a descrição da Ação :");
		String descricao = manager.scan.next();

		Acao acao = new Acao(valor);
		acao.setDescricao(descricao);

		manager.acoes.add(acao);
		System.out.println("[INFO] Ação adicionada com sucesso [" + acao.getDescricao() + " / " + manager.acoes.size() + "]!");
	}
}